package com.zybooks.timbrady_inventorytracker;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class UserDetailActivity extends AppCompatActivity {

    TextView textUser;
    String userNumStr, userNameStr, nameStr, roleStr;
    EditText textUpdateName;
    InventoryTrackerDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detail);

        // Declaring variables for text fields and buttons
        Intent intent = getIntent();
        userNumStr = intent.getStringExtra("userNumExtra");
        userNameStr = intent.getStringExtra("userNameExtra");
        nameStr = intent.getStringExtra("nameExtra");
        roleStr = intent.getStringExtra("roleExtra");
        db = new InventoryTrackerDatabase(this);
        textUpdateName = findViewById(R.id.editTextFirstName);
        Button btnUpdateFirstName = findViewById(R.id.buttonUpdateFirstName);

        // Button functionality to navigate back to user screen
        Button buttonAddUser = findViewById(R.id.buttonBackToUsers);
        buttonAddUser.setOnClickListener(listener -> userScreen());

        // Button functionality to delete a user
        Button btnDeleteUser = findViewById(R.id.buttonDeleteUser);
        Intent intent2 = new Intent(this, DisplayAllUsersActivity.class);

        // Setting up spinner for employee role dropdown box
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) Spinner spinnerRoles = findViewById(R.id.spinnerRole2);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this, R.array.roles,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinnerRoles.setAdapter(adapter);

        // Set default of spinner equal to current employee role
        if (roleStr.matches("Manager")) {
            int spinnerPosition = adapter.getPosition("Manager");
            spinnerRoles.setSelection(spinnerPosition);
        }

        btnUpdateFirstName.setOnClickListener(new View.OnClickListener() {

            @Override
            // Update user name. If no name is entered, the name will not change.
            public void onClick(View v) {
                String userNumTxt = intent.getStringExtra("userNumExtra");
                String nameTxt, roleTxt;

                // If user updates name, change it in the database
                if (textUpdateName.getText().toString().matches("")) {
                    nameTxt = nameStr;
                }
                else {
                    nameTxt = textUpdateName.getText().toString();
                }

                // If user updates role, change it in the database
                if (spinnerRoles.getSelectedItem() != roleStr) {
                    roleTxt = spinnerRoles.getSelectedItem().toString();
                }
                else {
                    roleTxt = roleStr;
                }

                // Check that an item was updated and display confirmation message
                Boolean checkUpdateUser = db.updateUser(userNumTxt, nameTxt, roleTxt);
                if (checkUpdateUser) {
                    Toast.makeText(UserDetailActivity.this, "Employee updated!", Toast.LENGTH_SHORT).show();
                    startActivity(intent2);
                }
            }
        });

        // Button to delete user
        btnDeleteUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Alert user to confirm delete
                confirmUserDeleteAlert();
            }
        });

        // Display autopopulated data at the top of the user edit screen
        textUser = findViewById(R.id.autoCompleteUser);
        textUser.setText(String.format("Name:  %s\nUser Num: %s\nUser Name:  %s\nRole:  %s",
                nameStr, userNumStr, userNameStr, roleStr));

    }

    // Alert user that they are about to delete an item
    private void confirmUserDeleteAlert(){
        Intent intent = getIntent();
        Intent intent2 = new Intent(this, DisplayAllUsersActivity.class);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete this item?");
        builder.setMessage("Are you sure you want to delete " + nameStr + "?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String userNumTxt = intent.getStringExtra("userNumExtra");

                // Check that an item was deleted and display a confirmation message
                Boolean checkUpdateUser = db.deleteUser(userNumTxt);
                if (checkUpdateUser) {
                    Toast.makeText(UserDetailActivity.this, "User deleted", Toast.LENGTH_SHORT).show();
                    startActivity(intent2);
                }
            }
        });

        // Toast message to confirm user was not deleted
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(UserDetailActivity.this, "User not deleted", Toast.LENGTH_SHORT).show();
            }
        });

        builder.create().show();
    }

    // Take user to user screen
    private void userScreen() {
        Intent intent = new Intent(this, DisplayAllUsersActivity.class);
        startActivity(intent);
    }
}